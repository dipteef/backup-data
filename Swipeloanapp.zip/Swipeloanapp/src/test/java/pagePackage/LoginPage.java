package pagePackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class LoginPage extends BaseTest {
	
	public LoginPage(AndroidDriver driver) {
		this.driver=driver;
	}
	
	String MobileNumber_xpath = "//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]";
	String GetStartedButton_xpath="//android.view.View[@content-desc=\"Get Started\"]";
	
	
	public void enterMobileNumber(String mobileNumber) throws InterruptedException {
		
		WebElement mobileNumber_element= driver.findElement(By.xpath(MobileNumber_xpath));
		mobileNumber_element.click();
		Thread.sleep(1000);
		mobileNumber_element.sendKeys(mobileNumber);
		Thread.sleep(2000);
		WebElement getstartedbutton_element= driver.findElement(By.xpath(GetStartedButton_xpath));
		getstartedbutton_element.click();
		
		}
	

}
