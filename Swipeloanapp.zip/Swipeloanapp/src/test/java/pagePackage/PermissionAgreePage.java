package pagePackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class PermissionAgreePage extends BaseTest {
	
	public PermissionAgreePage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String IAgrreButton_xpath="//android.widget.Button[@content-desc='I Agree']";
	
	public void PermissionAgree() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement IAgreeButton= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(IAgrreButton_xpath)));
		
//		WebElement IAgreeButton = driver.findElement(By.xpath(IAgrreButton_xpath));
		IAgreeButton.click();
	}
	

}
