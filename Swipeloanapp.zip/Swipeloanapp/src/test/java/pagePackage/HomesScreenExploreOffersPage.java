package pagePackage;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class HomesScreenExploreOffersPage extends BaseTest{
	
	public HomesScreenExploreOffersPage(AndroidDriver driver) {
		this.driver= driver;
	}
	


}
