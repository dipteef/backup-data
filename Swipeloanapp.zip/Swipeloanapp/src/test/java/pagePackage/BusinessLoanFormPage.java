package pagePackage;

import java.time.Duration;
import java.util.Collections;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class BusinessLoanFormPage extends BaseTest {
	
	public BusinessLoanFormPage(AndroidDriver driver) {
		this.driver= driver;
	}

	String ExploreOffers_xpath="//android.view.View[@content-desc=\"Explore Offers\"]";
	String BusinessType_xpath="//android.widget.ScrollView/android.view.View[4]";
	String ProprietorshipBusinessType_xpath= "//android.view.View[@content-desc=\"Proprietorship\"]";
	String IncorporationDate_xpath="//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[5]/android.view.View[6]";
	String DateEditField_xpath="android.widget.Button";
	String DateEnterField_xpath= "android.widget.EditText";
	String DateOk_xpath="//android.widget.Button[@content-desc=\"OK\"]";
	String PropertyOwnership_xpath="//android.view.View[@hint='Select Property Ownership']";
	String ResidenceOwnership_xpath="//android.view.View[@content-desc=\"Residence\"]";
	String BankAccountType_xpath="//android.view.View[@hint='Select Type of Bank Account']";
	String CurrentBankAccountType_xpath= "//android.view.View[@content-desc=\"Current\"]";
	String ContinueButton_xpath= "//android.view.View[@content-desc=\"Continue\"]";
	
	
	public void BusinessForm() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath(ExploreOffers_xpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(BusinessType_xpath)).click();
		driver.findElement(By.xpath(ProprietorshipBusinessType_xpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(IncorporationDate_xpath)).click();
		driver.findElement(By.className(DateEditField_xpath)).click();
		driver.findElement(By.className(DateEnterField_xpath)).click();
		driver.findElement(By.className(DateEnterField_xpath)).clear();
		driver.findElement(By.className(DateEnterField_xpath)).sendKeys("04/10/2022");
		driver.findElement(By.xpath(DateOk_xpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(PropertyOwnership_xpath)).click();
		driver.findElement(By.xpath(ResidenceOwnership_xpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(BankAccountType_xpath)).click();
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
	   	Sequence scroll = new Sequence(finger, 0);

	   	// Start at (500, 1500), move to (500, 500)
	   	scroll.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), 500, 1500));
	   	scroll.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
	   	scroll.addAction(finger.createPointerMove(Duration.ofMillis(600), PointerInput.Origin.viewport(), 500, 500));
	   	scroll.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	   	driver.perform(Collections.singletonList(scroll));

	   	driver.findElement(By.xpath(CurrentBankAccountType_xpath)).click();

	   	Thread.sleep(2000);
		driver.findElement(By.xpath(ContinueButton_xpath)).click();
		
		
	}
}
