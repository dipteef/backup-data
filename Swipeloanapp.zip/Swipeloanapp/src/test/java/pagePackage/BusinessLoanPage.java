package pagePackage;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;

public class BusinessLoanPage extends BaseTest{
	
	public BusinessLoanPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String BusinessLoan_xpath="Business Loan\nUpto 50 Lac";
	
	public void BusinessLoan() throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 

		WebElement businessloan = wait.until(ExpectedConditions.elementToBeClickable(
		        new AppiumBy.ByAccessibilityId(BusinessLoan_xpath)));
		
		businessloan.click();
		
	}

}
