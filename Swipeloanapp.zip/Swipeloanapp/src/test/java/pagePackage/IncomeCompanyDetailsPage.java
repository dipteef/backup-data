package pagePackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class IncomeCompanyDetailsPage extends BaseTest {

	public IncomeCompanyDetailsPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String CompanyNameField_xpath= "//android.widget.FrameLayout[@resource-id=\\\"android:id/content\\\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[7]/android.widget.EditText[1]";
	String CompanyDescriptionField_xpath="//android.widget.FrameLayout[@resource-id=\\\"android:id/content\\\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[7]/android.widget.EditText[2]";
	String PincodeField_xpath="//android.widget.FrameLayout[@resource-id=\\\"android:id/content\\\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[7]/android.widget.EditText[3]";
	String CityField_xpath="//android.widget.FrameLayout[@resource-id=\\\"android:id/content\\\"]/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[7]/android.widget.EditText[4]";
	String SaveemployerDetailsButton_xpath="//android.view.View[@content-desc=\\\"Save employer details\\\"]";
	
	public void CompanyDetails() throws InterruptedException {
		
		Thread.sleep(2000);
        WebElement companyName=driver.findElement(By.xpath(CompanyNameField_xpath));
        companyName.click();
        companyName.sendKeys("Bpointer Technologies");
        driver.hideKeyboard();
        
        Thread.sleep(2000);
        WebElement companyDescription= driver.findElement(By.xpath(CompanyDescriptionField_xpath));
        companyDescription.click();
        companyDescription.sendKeys("1215, Gera's Imperium Rise, Hinjewadi, Pune");
        driver.hideKeyboard();
        
        Thread.sleep(2000);
        WebElement pincode =driver.findElement(By.xpath(PincodeField_xpath));
        pincode.click();
        pincode.sendKeys("411057");
        driver.hideKeyboard();
        
        Thread.sleep(2000);
        WebElement city= driver.findElement(By.xpath(CityField_xpath));
        city.click();
        city.sendKeys("Pune");
        driver.hideKeyboard();
        
        Thread.sleep(2000);
        driver.findElement(By.xpath(SaveemployerDetailsButton_xpath)).click();
	}
}
