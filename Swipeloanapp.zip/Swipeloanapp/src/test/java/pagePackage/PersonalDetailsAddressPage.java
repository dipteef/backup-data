package pagePackage;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class PersonalDetailsAddressPage extends BaseTest{
	
	public PersonalDetailsAddressPage(AndroidDriver driver) {
		this.driver=driver;
	}
	
	String EditField_xpath= "android.widget.EditText";
	String ContinueButton_xpath= "//android.view.View[@content-desc=\"Continue\"]";
	
	public void AddressDetails() {
		
		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
	    	List<WebElement> editTextFields = driver.findElements(By.className(EditField_xpath));
	        System.out.println("Number of EditText fields found: " + editTextFields.size());

	        // Check if the list contains the required number of elements before interacting
	        if (editTextFields.size() >= 1) {

	            WebElement addressField = wait.until(ExpectedConditions.elementToBeClickable(editTextFields.get(0)));
	            addressField.click();
	            addressField.sendKeys("Hinjewadi, Pune");
	            driver.hideKeyboard();

	            WebElement pincodeField = wait.until(ExpectedConditions.elementToBeClickable(editTextFields.get(1)));
	            pincodeField.click();
	            pincodeField.sendKeys("411057");
	            driver.hideKeyboard();
	            
	            WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ContinueButton_xpath)));
	            continueButton.click();
	            
        	}
	}
	
}
