package pagePackage;

import org.openqa.selenium.By;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class IncomeRelationshipStatusPage extends BaseTest{
	
	public IncomeRelationshipStatusPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String SingleRelationshipStatus_xpath= "//android.widget.Button[@content-desc=\\\"Single\\\"]";
	String SubmitButton_xpath= "//android.view.View[@content-desc=\\\"Submit\\\"]";
	
	public void RelationshipStatus() throws InterruptedException {
		
		Thread.sleep(2000);
        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Single\"]")).click();
        
        Thread.sleep(2000);
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Submit\"]")).click();
        
	}

}
