package pagePackage;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class VerifyOTPPage extends BaseTest {
	
	public VerifyOTPPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String otp="121512";
	String otpfield_xpath="android.widget.EditText";
	String ContinueButton_xpath= "//android.view.View[@content-desc=\"Continue\"]";
	String AllowButton_xpath="//android.widget.Button[@content-desc='Allow']";
	
	public void continueButtonClick() throws InterruptedException {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		WebElement otpInputField = driver.findElement(By.className(otpfield_xpath));
		otpInputField.click();
//	    otpInputField.sendKeys(otp);
		List<WebElement> otpFields = driver.findElements(By.className(otpfield_xpath));
	    
	    if (otpFields.size() == 1) {
	        System.out.println("Single OTP input field detected.");
	        otpFields.get(0).click();
/*	       
			WebElement allowButton= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AllowButton_xpath)));
			allowButton.click();
			*/
	        otpFields.get(0).sendKeys(otp);
	    } 

		
     	  Thread.sleep(4000);
     	  WebElement continueButton= driver.findElement(By.xpath(ContinueButton_xpath));
 		  continueButton.click();
     	  Thread.sleep(2000);
       	  WebElement continueButton2= driver.findElement(By.xpath(ContinueButton_xpath));
		  continueButton2.click();
		
	}

}
