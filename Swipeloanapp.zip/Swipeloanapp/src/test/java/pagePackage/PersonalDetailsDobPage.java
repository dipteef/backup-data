package pagePackage;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class PersonalDetailsDobPage extends BaseTest{
	
	public PersonalDetailsDobPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	public void Dob() {
		
	}

}
