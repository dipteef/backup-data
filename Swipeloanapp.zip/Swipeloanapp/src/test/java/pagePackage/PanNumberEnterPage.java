package pagePackage;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class PanNumberEnterPage extends BaseTest {
	
	public PanNumberEnterPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String Panedittext_xpath="//*[@hint='Enter PAN Number']";
	String Verifybutton_xpath="//android.widget.Button[@content-desc='Verify']";
	String Yesbutton_xpath="//android.widget.Button[@content-desc='YES']";
	
	public void PanNumber(String pannmuber) throws InterruptedException {
		 WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));
	        WebElement panEditText = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath(Panedittext_xpath)));
	     	panEditText.click();
	     	panEditText.sendKeys(pannmuber);
	       	driver.hideKeyboard();
	        Thread.sleep(5000);
	        WebElement continueButton = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath(Verifybutton_xpath)));
	        continueButton.click();
	     	 	
			  
			Thread.sleep(5000);
			driver.findElement(By.xpath(Yesbutton_xpath)).click();
		
		
	}

}
