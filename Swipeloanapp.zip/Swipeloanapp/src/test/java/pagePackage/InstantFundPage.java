package pagePackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.AppiumBy;

import io.appium.java_client.android.AndroidDriver;

public class InstantFundPage extends BaseTest{
	
	public InstantFundPage(AndroidDriver driver) {
		this.driver= driver;
	}
	
	String InstaFund_xpath= "Insta Fund\nUpto 1 Lac";
	String ExploreOffers_xpath= "//android.view.View[@content-desc=\"Explore Offers\"";
	String Eligible_xpath= "//android.widget.Button[@content-desc=\"Eligible\"])[1]";
	
	public void InstaFund() throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement instafund = wait.until(ExpectedConditions.elementToBeClickable(
		        new AppiumBy.ByAccessibilityId(InstaFund_xpath)));
        instafund.click();
 //       driver.findElement(MobileBy.AccessibilityId("Insta Fund\nUpto 1 Lac")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath(ExploreOffers_xpath)).click();
        
        Thread.sleep(2000);
        driver.findElement(By.xpath(Eligible_xpath)).click();
	}

}
