package pagePackage;

import java.time.Duration;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.android.AndroidDriver;

public class HomeLoanFormPage extends BaseTest{

	public HomeLoanFormPage(AndroidDriver driver) {
		this.driver= driver;
	}

	String ExploreOffers_xpath="//android.view.View[@content-desc=\"Explore Offers\"]";
	String PropertyType_xpath="//android.view.View[@hint='Select Property Type']";
	String ResalePropertyType_xpath= "//android.view.View[@content-desc=\"Resale Property\"]";

	String EnterField_xpath= "android.widget.EditText";
	
	String ContinueButton_xpath= "//android.view.View[@content-desc=\"Continue\"]";
	
	
	public void HomeForm() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath(ExploreOffers_xpath)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(PropertyType_xpath)).click();
		driver.findElement(By.xpath(ResalePropertyType_xpath)).click();
		Thread.sleep(2000);
		List<WebElement> editTextFields = driver.findElements(By.className(EnterField_xpath));
        System.out.println("Number of EditText fields found: " + editTextFields.size());
        
        if (editTextFields.size() >= 3) {

        	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            WebElement propertyValueField = wait.until(ExpectedConditions.elementToBeClickable(editTextFields.get(0)));
            propertyValueField.click();
            propertyValueField.clear();
            propertyValueField.sendKeys("1000000");
            driver.hideKeyboard();
            
            WebElement propertyCityField = wait.until(ExpectedConditions.elementToBeClickable(editTextFields.get(1)));
            propertyCityField.click();
            propertyCityField.sendKeys("Pune");
            driver.hideKeyboard();
            
            WebElement propertyPincodeField = wait.until(ExpectedConditions.elementToBeClickable(editTextFields.get(2)));
            propertyPincodeField.click();
        
            propertyPincodeField.sendKeys("411057");
            driver.hideKeyboard();
            
            WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ContinueButton_xpath)));
            continueButton.click();
            
        }
        
	
		
	}
}
