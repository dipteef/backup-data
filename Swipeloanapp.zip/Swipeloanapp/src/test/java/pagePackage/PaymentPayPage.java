package pagePackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basePackage.BaseTest;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;

public class PaymentPayPage extends BaseTest {
	
	public PaymentPayPage(AndroidDriver driver) {
		this.driver= driver;
	}

	String UpiAppClick_xpath="//android.webkit.WebView[@content-desc='primary_webview']";
	String ProceedToPayButton_xpath="//android.widget.TextView[@text='PROCEED TO PAY']";
	
	public void Pay() throws InterruptedException {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	     WebElement paymentApp = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(UpiAppClick_xpath)));
	     paymentApp.click();
	     
	     Thread.sleep(4000);
	     driver.findElement(AppiumBy.xpath(ProceedToPayButton_xpath)).click();

	}
}
