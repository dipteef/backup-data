package Swipeloan.Swipeloanapp;

public class Dob extends Personaldetailsdob {
	
	public void Test1() {
		
	}

}
